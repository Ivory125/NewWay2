''' 1. '''
if app.ENABLE_MULTI_LANGUAGE_SYSTEM:
	MULTI_LANGUAGE_NEED_RESTART_CLIENT = True # Enable the requirement to restart client after changing language in game