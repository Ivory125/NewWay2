''' 1. '''
# Search
	def BINARY_AppendNotifyMessage(self, type):

# Add above
	if app.ENABLE_EXTENDED_WHISPER_DETAILS and app.ENABLE_MULTI_LANGUAGE_SYSTEM:
		def BINARY_RecieveWhisperDetails(self, name, country):
			if self.interface:
				self.interface.RecieveWhisperDetails(name, country)