/// 1.
// Search @ bool CInstanceBase::Create
		SetHair(c_rkCreateData.m_dwHair);

// Add above
#ifdef ENABLE_MULTI_LANGUAGE_SYSTEM
		SetLanguage(c_rkCreateData.m_bLanguage);
#endif