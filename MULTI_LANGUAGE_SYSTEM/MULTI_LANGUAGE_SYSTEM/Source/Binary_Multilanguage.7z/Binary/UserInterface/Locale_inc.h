/// 1.
// Add
#define ENABLE_MULTI_LANGUAGE_SYSTEM // Multi language system
#define ENABLE_EXTENDED_WHISPER_DETAILS // Extended whisper target information, created mainly for multi-language country flag but can be used for other information.
#define ENABLE_ATLAS_MARK_INFO // Enable atlas mark info from client