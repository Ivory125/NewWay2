/// 1.
// Search @ typedef struct STextTail
			CGraphicTextInstance* pTitleTextInstance;
			CGraphicTextInstance* pLevelTextInstance;

// Add below
#ifdef ENABLE_MULTI_LANGUAGE_SYSTEM
			CGraphicImageInstance* pLanguageInstance;
#endif