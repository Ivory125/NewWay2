/// 1.
// Add
#define __MULTI_LANGUAGE_SYSTEM__ // Multi language system
#define __EXTENDED_WHISPER_DETAILS__ // Extended whisper details